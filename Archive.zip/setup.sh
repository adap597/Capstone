export SECRET='ihxq2MKyjX_XRxdxQIbXLYD1rJohSUpY9QGwbW-AZC1kV0VP-YiZVk4nxvyOEIfv'
export AUTH0_DOMAIN="udacfsnd.us.auth0.com" 
export ALGORITHMS="RS256"
export API_AUDIENCE="Casting" 

export DATABASE_URL="postgres://gtppoatzffgybr:849f56f797fa3798c249b5b012c5c70faf205b9323a9c337c6bf9ecbf3b3bfc3@ec2-54-236-137-173.compute-1.amazonaws.com:5432/d5jabkfovb1acg"
export FLASK_APP=app
export FLASK_DEBUG=True
export FLASK_ENVIRONMENT=debug